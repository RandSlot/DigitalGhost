# код из предыдущего шага
from aiogram import Bot, Dispatcher, types
# логика хранения воспоминаний
