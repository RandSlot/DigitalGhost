TELEGRAM_TOKEN_GHOST = "ВАШ_ТОКЕН_БОТА_ПРИЗРАКА"
TELEGRAM_TOKEN_AFTERGLOW = "ВАШ_ТОКЕН_БОТА_AFTERGLOW"
OPENAI_API_KEY = "ВАШ_OPENAI_API_КЛЮЧ"
